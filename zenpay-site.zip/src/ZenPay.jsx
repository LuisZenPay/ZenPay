import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CheckCircle, MessageSquareText, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function ZenPay() {
  return (
    <div className="min-h-screen bg-white text-gray-800 p-4 md:p-10">
      {/* Hero */}
      <section className="max-w-5xl mx-auto text-center py-20">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-6xl font-bold mb-6 text-blue-600"
        >
          ZenPay: Seu Controle Financeiro via WhatsApp
        </motion.h1>
        <p className="text-lg md:text-xl mb-8">
          Automatize seu controle de gastos, receba relatórios e tenha tudo salvo na nuvem. Simples. Inteligente. Pelo WhatsApp.
        </p>
        <Button size="lg" className="text-lg px-6 py-4">Começar Agora</Button>
      </section>

      {/* Funcionalidades */}
      <section className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto py-16">
        <Card className="shadow-xl rounded-2xl">
          <CardContent className="p-6 flex flex-col items-center text-center">
            <MessageSquareText className="w-10 h-10 text-blue-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Registro por WhatsApp</h3>
            <p>Envie mensagens, áudios ou fotos para registrar transações automaticamente.</p>
          </CardContent>
        </Card>
        <Card className="shadow-xl rounded-2xl">
          <CardContent className="p-6 flex flex-col items-center text-center">
            <CheckCircle className="w-10 h-10 text-blue-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Relatórios Interativos</h3>
            <p>Acompanhe gráficos e categorias de gastos em tempo real pela web.</p>
          </CardContent>
        </Card>
        <Card className="shadow-xl rounded-2xl">
          <CardContent className="p-6 flex flex-col items-center text-center">
            <Zap className="w-10 h-10 text-blue-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Bot Inteligente</h3>
            <p>Nosso bot entende seus comandos e responde com agilidade e precisão.</p>
          </CardContent>
        </Card>
      </section>

      {/* Planos */}
      <section className="max-w-4xl mx-auto text-center py-20">
        <h2 className="text-3xl font-bold mb-10">Planos para Todos os Perfis</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="shadow-lg border border-gray-200">
            <CardContent className="p-6">
              <h3 className="text-2xl font-semibold mb-2">Gratuito</h3>
              <p className="mb-4">Perfeito para começar</p>
              <ul className="text-left mb-6">
                <li>- 10 registros/mês</li>
                <li>- Relatórios básicos</li>
                <li>- 1 número de WhatsApp</li>
              </ul>
              <Button variant="outline">Selecionar</Button>
            </CardContent>
          </Card>

          <Card className="shadow-lg border border-gray-200">
            <CardContent className="p-6">
              <h3 className="text-2xl font-semibold mb-2 text-blue-600">Premium - R$19,90/mês</h3>
              <p className="mb-4">Para quem quer mais controle</p>
              <ul className="text-left mb-6">
                <li>- Registros ilimitados</li>
                <li>- Relatórios completos</li>
                <li>- Integração com categorias</li>
              </ul>
              <a href="https://buy.stripe.com/test_00g6rg5l57XT3sA6oo">
                <Button className="bg-blue-600 text-white w-full">Assinar Agora</Button>
              </a>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center py-10 text-gray-500 text-sm">
        ZenPay © {new Date().getFullYear()} — Todos os direitos reservados
      </footer>
    </div>
  );
}